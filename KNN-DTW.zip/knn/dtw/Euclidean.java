package knn;

import java.util.Map.Entry;

public class Euclidean implements Metric {
	/**
	 * euclidian = sqrt( sigma( (r1[i] - r2[i])^2 ) )
	 */

	public double compute(Record r1, Record r2) {
		double res = 0;

		double sum = 0, r1d, r2d;
		//System.out.println("Primeiro SUM: "+sum);
		/*
		int dimension = r1.attributes.size();
		for (int i = 0; i < dimension; i++) {
			r1d = r1.attributes.get(i);
			r2d = r2.attributes.get(i);
			sum += (r1d-r2d)*(r1d-r2d);
		}
		*/
		for (Entry<Integer, Double> entry : r1.attributes.entrySet())
		{
			int i = entry.getKey();
			//System.out.println("I: "+i);
			if (r2.attributes.containsKey(i))
			{
				//System.out.print("I: "+r1.attributes.get(i)+"   ");
				//System.out.println("I2: "+r2.attributes.get(i));
//System.out.println("Teste 1: "+r1.attributes.values());
//System.out.println("Teste 2: "+r1.attributes.toString());
//System.out.println("Teste I: "+i);

				r1d = r1.attributes.get(i);
				r2d = r2.attributes.get(i);
				sum += (r1d-r2d)*(r1d-r2d);
				//System.out.println("SUM: "+sum);

			}
		}

		return Math.sqrt(sum);
	}

}
