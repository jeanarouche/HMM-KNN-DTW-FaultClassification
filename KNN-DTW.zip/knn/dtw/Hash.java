package knn;

public interface Hash<In, Out> {
	Out hash(In input);
}
